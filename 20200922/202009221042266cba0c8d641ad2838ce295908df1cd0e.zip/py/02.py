# Define a function that splits a list and puts the same adjacent elements together.
#
# 定义函数实现列表的分割，即列表中相邻的相同元素形成一个列表。
#
# Input: [0,0,0,1,1,2,3,3,3,2,3,3,0,0]
#
# Output: [0,0,0],[1,1],[2],[3,3,3],[2],[3,3],[0,0]
import copy

def list_s(ls):
    ls.append("#")
    lss = []
    als = []
    for i in ls:
        if len(als) == 0:
            als.append(i)
        else:
            if als[0] == i:
                als.append(i)
            else:
                lss.append(copy.deepcopy(als))  #   append是浅拷贝，不太懂？   https://www.runoob.com/w3cnote/python-append-deepcopy.html
                als.clear()
                als.append(i)
    return lss

s=input()
ls=[int(x) for x in s.split()]
print(ls)
lss=list_s(ls)
for x in lss:
    print(x,end="," if x != lss[-1] else '')