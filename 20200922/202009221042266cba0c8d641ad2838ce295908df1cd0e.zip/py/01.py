# Input an integer N (0<N<1000), then input N integers. Check whether these N integers form an arithmetic progression.
#
# 输入一个整数N，然后输入N个整数。判断这N个整数是否可以构建一个等差数列。（0<N<1000）
#
# 输入： 第一行为一个整数N，第二行为N个整数。
#
# 输出： 可以构成等差数列输出True，否则输出False。
#
# 示例：
#
# (1)input： 10
#
# 5 3 2 1 7 6 4 8 10 9
#
# output: True
#
# (2)input： 5
#
# 4 6 3 2 7
#
# output: False
#
# 提示：注意输入的数无序。

N=int(input("input:"))
s=input()
ls=[int(x) for x in s.split()][0:N]#只取前n个数
ls.sort()# 排序
if len(ls)==1:print("output:Ture")
else:
    a=ls[1]-ls[0]
    flag=1
    i = 0
    for x in ls:
        if x!=ls[0]+i*a:
            flag=0
            break
        i+=1
    if flag==0:
        print("output:False")
    else:
        print("output:Ture")

