x=[1,2,3,4,5,6]
y=[]
for i in x:
    y.append(i)
print(y)