# **自定义函数 twonums_sum(n, lst)，在列表 lst 中查找是否有两数之和等于 n，若有则返回两数的下标，
# 否则返回-1。对于一个不包含重复数字的有序列表[1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 15, 18, 19, 20, 21, 29, 34, 54, 65]，
# 从键盘输入 n，调用函数twonums_sum()输出满足条件的两个数的下标（找到一组即可且要求其中的一个数尽量小），若所有数均不满足条件则输出“ not found”。
# [输入样例]
# 17
# [输出样例]
# (1, 10)
def twonums_sum(n, lst):
    i = j = 0
    flag = 0
    for x in ls:
        j = 0
        for y in ls:
            if (x + y == n):
                print(i, j)
                flag = 1
                break
            j += 1
        if flag==1:
            break
        i += 1
    if flag == 0:
        print("not found")
        return -1
    else :
        return i,j

s=input("input list:")
ls=[int(x) for x in s.split()]
n=int(input("input a number:"))
t=twonums_sum(n,ls)
if t!=-1:
    print(t)