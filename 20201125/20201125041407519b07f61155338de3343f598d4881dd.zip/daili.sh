#!/bin/bash 
echo "下载代理"
wget http://47.100.252.9/daili.txt -O daili.txt