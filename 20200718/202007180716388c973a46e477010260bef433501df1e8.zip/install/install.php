<?php
$t = array_keys(array_map('trim', $_POST), '');
if ($t) {
    echo "<script>alert('参数不可为空');location.href='" . $_SERVER["HTTP_REFERER"] . "';</script>";
} else {
    if (isset($_GET['act']) && $_GET['act'] == 'a') {
        if ($_POST['sm']!='yes'){
            die('请先阅读免责申明');
        }
        $conn = mysqli_connect($_POST['host'], $_POST['user'], $_POST['pass']);
        if (! $conn) {
            die("连接失败: " . mysqli_connect_error());
        }
        if (mysqli_select_db($conn, $_POST['dbname'])) {
            // 创建管理员表
            mysqli_query($conn, "set names utf8");
            mysqli_query($conn, "CREATE TABLE IF NOT EXISTS `admin`(
                `id` int(11) NOT NULL AUTO_INCREMENT,
                  `admin` text,
                  `pass` text,
                  PRIMARY KEY (`id`)
                )ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;");
            // 插入管理员账号密码
            mysqli_query($conn, "insert into admin (admin,pass) values ('{$_POST['admin']}','{$_POST['password']}')");
            // 创建留言信息表
            mysqli_query($conn, "CREATE TABLE IF NOT EXISTS `info`(
                 `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `content` longtext,
  `ip` char(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
                )ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;");
            // 创建卡密信息表
            mysqli_query($conn, "CREATE TABLE IF NOT EXISTS `km`(
                `id` int(11) NOT NULL AUTO_INCREMENT,
  `km` longtext,
  `type` char(255) DEFAULT NULL,
  `num` int(11) DEFAULT NULL,
  `date_start` char(255) DEFAULT NULL,
  `date_end` char(255) DEFAULT NULL,
  `state` char(255) DEFAULT '未使用',
  PRIMARY KEY (`id`)
                )ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;");
            // 创建自定义文档信息表
            mysqli_query($conn, "CREATE TABLE IF NOT EXISTS `text`(
                `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text,
  `text` longtext,
  PRIMARY KEY (`id`)
                )ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;");
            // 创建用户信息表
            mysqli_query($conn, "CREATE TABLE IF NOT EXISTS `user`(
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` char(255) DEFAULT NULL COMMENT '用户ID',
  `user_pass` varchar(255) DEFAULT NULL COMMENT '用户密码',
  `user_pass1` varchar(255) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL COMMENT '用户名',
  `user_email` char(255) DEFAULT NULL COMMENT '用户邮箱',
  `email_or` char(255) DEFAULT 'true' COMMENT '邮箱验证',
  `state` char(255) DEFAULT '白名单' COMMENT '账号状态',
  `i_code` int(11) DEFAULT NULL COMMENT '邀请码',
  `i_cal` longtext COMMENT '被邀请码',
  `ib` int(11) DEFAULT '0' COMMENT 'i币',
  `exp` int(11) DEFAULT '0' COMMENT '经验',
  `vip` char(255) DEFAULT 'false' COMMENT 'VIP',
  `vip_enddate` char(255) DEFAULT NULL COMMENT 'vip到期时间',
  `signin` int(11) DEFAULT '0' COMMENT '签到次数',
  `signin_date` char(255) DEFAULT NULL COMMENT '最后一次签到时间',
  `ip` char(255) DEFAULT NULL COMMENT '注册IP',
  `time` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
                )ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;");
            mysqli_close($conn);
            $config = file_get_contents('../config/mysql_config.php');
            $config = preg_replace("/define\('DB_HOST','.*?'\)/", "define('DB_HOST','{$_POST['host']}')", $config);
            $config = preg_replace("/define\('DB_USER','.*?'\)/", "define('DB_USER','{$_POST['user']}')", $config);
            $config = preg_replace("/define\('DB_PASS','.*?'\)/", "define('DB_PASS','{$_POST['pass']}')", $config);
            $config = preg_replace("/define\('DB_DBNAME','.*?'\)/", "define('DB_DBNAME','{$_POST['dbname']}')", $config);
            file_put_contents('../config/mysql_config.php', $config);
            rename('install.php', 'install.lock');
            header('Location: ../i7/login/login.html');
        } else {
            echo "<script>alert('未找到数据库');</script>";
        }
    }
}
?>

<html lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport"
	content="initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0,user-scalable=no,minimal-ui">
<title>本程序(以下简称源码)仅供技术交流，请勿用于商业及非法用途，如产生法律纠纷与作者无关</title>
<link rel="stylesheet" type="text/css" href="../css/boostrap.css" />
<style type="text/css">
.inputDiv {
	font-size: 0;
}
</style>
</head>
<body>
	<nav class="navbar navbar-fixed-top navbar-default">
		<div class="container">
			<div class="navbar-header">
				<span class="navbar-brand">i7网络验证</span>
			</div>
		</div>
	</nav>
	<div class="container" style="padding-top: 60px;">
		<div class="col-xs-12 col-sm-8 col-lg-6 center-block"
			style="float: none;">

			<div class="panel panel-primary">
				<div class="panel-heading">
					<h3 class="panel-title" align="center">安装程序</h3>
				</div>
				<div class="panel-body">
					<form action="install.php?act=a" class="form-sign" method="post">
						<center>数据库信息</center>
						<label for="name">数据库地址:</label> <input type="text"
							class="form-control" name="host" value="localhost"
							placeholder="数据库地址"> <label for="name">数据库用户名:</label> <input
							type="text" class="form-control" name="user" value=""
							placeholder="数据库用户名"> <label for="name">数据库密码:</label> <input
							type="text" class="form-control" name="pass" value=""
							placeholder="数据库密码"> <label for="name">数据库名:</label> <input
							type="text" class="form-control" name="dbname" value=""
							placeholder="数据库名"> <br>
						<center>管理员信息</center>
						<label for="name">账号:</label> <input type="text"
							class="form-control" name="admin" value="" placeholder="请输入账号"> <label
							for="name">密码:</label> <input type="text" class="form-control"
							name="password" value="" placeholder="请输入密码"> 
							<br><center><p><input type="checkbox" name="sm" value="yes" /> <a href="sm.html">我已阅读并同意《免责申明》</a></p></center><input
							type="submit" class="btn btn-primary btn-block" name="submit"
							value="安装">
					</form>
				</div>
			</div>

</body>
</script>
</html>