<?php
session_start();
header("Content-type: text/html; charset=utf-8");
define("ROOT",dirname(__FILE__));
set_include_path(".".PATH_SEPARATOR.ROOT."/lib".PATH_SEPARATOR.ROOT."/config");
require_once 'mysql_config.php';
require_once 'user_log_configs.php';
require_once 'alert.php';
require_once 'mysql.php';
require_once 'admin.php';
if (!connect()){
    header('Location: ../install/install.php');
}