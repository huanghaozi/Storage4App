<?php 
//用户等级称号
global $user_log_or,$user_log_vip_or,$user_log_vip_date,$user_email_or,$key_or,$key_cheng,$key_chu,$user_lv1_name,$user_lv2_name,$user_lv3_name,$user_lv1_exp,$user_lv2_exp,$user_lv3_exp;
$user_lv1_name="超凡";
$user_lv1_exp="100";
$user_lv2_name="入圣";
$user_lv2_exp="300";
$user_lv3_name="仙尊";
$user_lv3_exp="700";
//系统ib名
$ib='ib';
//账号最小限制
$user_s="6";
//账号最大限制
$user_b="12";
//是否可注册
$user_log_or="true";
//是否开启注册即送VIP
$user_log_vip_or="false";
//设置注册送VIP到期时间
$user_log_vip_date="1";
//是否开启邮箱验证
$user_email_or="false";
//是否开启key
$key_or="false";
$key_cheng="4365";
$key_chu="3654";
//是否开启签到
$signin_or="true";
$signin_exp="10";
$signin_ib="2";
//邮箱配置
$email="3571717467@qq.com";
$email_pass="";
//留言配置
$info_or="true";
$info_date="60";



function update_user_config($file, $data,$type="string"){
    if(!file_exists($file)){
        return false;
    }
    if(!is_array($data)){
        return false;
    }
    $str=file_get_contents($file);
    $str2=$str;
    
    
    foreach($data as $key=>$val){
        $pattern='/'.$key.'=(.*?)\;/i';
        if(is_int($val)){
            $str2=preg_replace($pattern,$key.'='.$val.';',$str2);
        }else{
            $str2=preg_replace($pattern,$key.'="'.$val.'";',$str2);
        }
    }
    file_put_contents($file,$str2);
    return true;
}
?>