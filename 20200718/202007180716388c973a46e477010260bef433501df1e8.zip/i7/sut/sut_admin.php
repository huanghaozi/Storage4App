<?php
require_once '../../include.php';
admin(1);
if ($_POST==null){
    $sql = "select * from admin";
    $row=one($sql);
    ?>




<html lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="viewport" content="initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0,user-scalable=no,minimal-ui">
<title>i7网络验证</title>
<link rel="stylesheet" type="text/css" href="../../css/boostrap.css"/>
<link rel="stylesheet" type="text/css" href="../../css/layui.css"/>
<style type="text/css">
	.inputDiv {
  font-size: 0;
}
</style>
</head>
<body>
<nav class="navbar navbar-fixed-top navbar-default">
    <div class="container">
      <div class="navbar-header">
        <span class="navbar-brand">i7网络验证</span>
      </div>
    </div>
  </nav>
  <div class="container" style="padding-top:60px;">
    <div class="col-xs-12 col-sm-8 col-lg-6 center-block" style="float: none;">

<div class="panel panel-primary">
	<div class="panel-heading">
		<h3 class="panel-title" align="center">管理员配置</h3>
	</div>
	<div class="panel-body">
		<input type="submit" class="btn btn-primary btn-block" name="Submit" onclick="javascript:history.back(-1);" value="返回上一页"></br>
		<form action="sut_admin.php" class="form-sign" method="post">
		<table style="margin: 0px;padding: 0px;"> 
        <label for="name" style="width: 70%;">修改管理员账号:</label>
		<input type="text" class="controla" name="admin" value="<?php echo $row['admin']?>"  id="" style="width: 30%;"></br></br>
		 <label for="name" style="width: 70%;">修改管理员密码:</label>
		<input type="text" class="controla" name="pass" value="<?php echo $row['pass']?>"  id="" style="width: 30%;"></br></br>
		</table></br>
		<input type="submit" class="btn btn-primary btn-block" name="submit" value="立即修改">
		</form>
		
</div>
</div>
</div>
</div>
</body>
</html>
<?php 
}else {
    $sql = "update admin set admin='{$_POST['admin']}',pass='{$_POST['pass']}' where id=1";
    history("修改成功");
}










?>