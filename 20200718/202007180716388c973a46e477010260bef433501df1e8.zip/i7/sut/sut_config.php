<?php
require_once '../../include.php';
admin(1);
if ($_POST==null){
    ?>




<html lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="viewport" content="initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0,user-scalable=no,minimal-ui">
<title>i7网络验证</title>
<link rel="stylesheet" type="text/css" href="../../css/boostrap.css"/>
<link rel="stylesheet" type="text/css" href="../../css/layui.css"/>
<style type="text/css">
p{
text-align: center;
}
</style>
</head>
<body>
<nav class="navbar navbar-fixed-top navbar-default">
    <div class="container">
      <div class="navbar-header">
        <span class="navbar-brand">i7网络验证</span>
      </div>
    </div>
  </nav>
  <div class="container" style="padding-top:60px;">
    <div class="col-xs-12 col-sm-8 col-lg-6 center-block" style="float: none;">

<div class="panel panel-primary">
	<div class="panel-heading">
		<h3 class="panel-title" align="center">参数配置</h3>
	</div>
	<div class="panel-body">
		<input type="submit" class="btn btn-primary btn-block" name="Submit" onclick="javascript:history.back(-1);" value="返回上一页"></br>
		<form action="sut_config.php" class="form-sign" method="post">
		<p>用户等级经验称号配置:</p><br><br>
		<table style="margin: 0px;padding: 0px;">
        <label for="name" style="width: 45%;">LV1(经验-称号):</label>
		<input type="text" class="controla" name="user_lv1_exp" value="<?php echo $user_lv1_exp?>"  id="" style="width: 25%;">   &nbsp;
		<input type="text" class="controla" name="user_lv1_name" value="<?php echo $user_lv1_name?>"  id="" style="width: 25%;"><br><br>
        <label for="name" style="width: 45%;">LV2(经验-称号):</label>
		<input type="text" class="controla" name="user_lv2_exp" value="<?php echo $user_lv2_exp?>"  id="" style="width: 25%;">   &nbsp;
		<input type="text" class="controla" name="user_lv2_name" value="<?php echo $user_lv2_name?>"  id="" style="width: 25%;"><br><br>
		<label for="name" style="width: 45%;">LV3(经验-称号):</label>
		<input type="text" class="controla" name="user_lv3_exp" value="<?php echo $user_lv3_exp?>"  id="" style="width: 25%;">   &nbsp;
		<input type="text" class="controla" name="user_lv3_name" value="<?php echo $user_lv3_name?>"  id="" style="width: 25%;"><br><br>
		</table></br>
		<input type="submit" class="btn btn-primary btn-block" name="submit" value="保存设置">
		</form>
		
</div>
</div>
</div>
</div>
</body>
</html>
<?php 
}else {
    $data=array(
        "user_lv1_exp"=>$_POST['user_lv1_exp'],
        "user_lv1_name"=>$_POST['user_lv1_name'],
        "user_lv2_exp"=>$_POST['user_lv2_exp'],
        "user_lv2_name"=>$_POST['user_lv2_name'],
        "user_lv3_exp"=>$_POST['user_lv3_exp'],
        "user_lv3_name"=>$_POST['user_lv3_name'],
    );
    if(update_user_config('../../config/user_log_configs.php', $data)){
        history('修改成功');
    }else {
        history('修改失败');
    }
    
    
    
}










?>