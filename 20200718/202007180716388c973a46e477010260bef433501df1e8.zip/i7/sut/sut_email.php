<?php
require_once '../../include.php';
admin(1);
if ($_POST==null){
    ?>




<html lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="viewport" content="initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0,user-scalable=no,minimal-ui">
<title>i7网络验证</title>
<link rel="stylesheet" type="text/css" href="../../css/boostrap.css"/>
<link rel="stylesheet" type="text/css" href="../../css/layui.css"/>
<style type="text/css">
	.inputDiv {
  font-size: 0;
}
</style>
</head>
<body>
<nav class="navbar navbar-fixed-top navbar-default">
    <div class="container">
      <div class="navbar-header">
        <span class="navbar-brand">i7网络验证</span>
      </div>
    </div>
  </nav>
  <div class="container" style="padding-top:60px;">
    <div class="col-xs-12 col-sm-8 col-lg-6 center-block" style="float: none;">

<div class="panel panel-primary">
	<div class="panel-heading">
		<h3 class="panel-title" align="center">邮箱配置</h3>
	</div>
	<div class="panel-body">
		<input type="submit" class="btn btn-primary btn-block" name="Submit" onclick="javascript:history.back(-1);" value="返回上一页"></br>
		<form action="sut_email.php" class="form-sign" method="post">
		<table style="margin: 0px;padding: 0px;">
       
        
        <label for="name" style="width: 50%;">发信邮箱:</label>
		<input type="text" class="controla" name="email" value="<?php echo $email?>"  id="" style="width: 50%;"></br></br>
		 <label for="name" style="width: 50%;">邮件授权码:</label>
		<input type="text" class="controla" name="email_pass" value="<?php echo $email_pass?>"  id="" style="width: 50%;"></br></br>
		</table></br>
		<input type="submit" class="btn btn-primary btn-block" name="submit" value="保存设置">
		</form>
		<br><input type="submit" class="btn btn-primary btn-block" name="Submit" onclick="javascript:location.href='https://jingyan.baidu.com/article/6079ad0eb14aaa28fe86db5a.html'" value="如何获取授权码">
		
</div>
</div>
</div>
</div>
</body>
</html>
<?php 
}else {
    $data=array(
        "email"=>$_POST['email'],
        "email_pass"=>$_POST['email_pass'],
    );
    if(update_user_config('../../config/user_log_configs.php', $data)){
        history('修改成功');
    }else {
        history('修改失败');
    }
    
    
    
}










?>