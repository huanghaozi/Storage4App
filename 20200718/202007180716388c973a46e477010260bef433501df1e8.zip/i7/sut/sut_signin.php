<?php
require_once '../../include.php';
admin(1);
if ($_POST==null){
    ?>




<html lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="viewport" content="initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0,user-scalable=no,minimal-ui">
<title>i7网络验证</title>
<link rel="stylesheet" type="text/css" href="../../css/boostrap.css"/>
<link rel="stylesheet" type="text/css" href="../../css/layui.css"/>
<style type="text/css">
	.inputDiv {
  font-size: 0;
}
</style>
</head>
<body>
<nav class="navbar navbar-fixed-top navbar-default">
    <div class="container">
      <div class="navbar-header">
        <span class="navbar-brand">i7网络验证</span>
      </div>
    </div>
  </nav>
  <div class="container" style="padding-top:60px;">
    <div class="col-xs-12 col-sm-8 col-lg-6 center-block" style="float: none;">

<div class="panel panel-primary">
	<div class="panel-heading">
		<h3 class="panel-title" align="center">签到配置</h3>
	</div>
	<div class="panel-body">
		<input type="submit" class="btn btn-primary btn-block" name="Submit" onclick="javascript:history.back(-1);" value="返回上一页"></br>
		<form action="sut_signin.php" class="form-sign" method="post">
		<table style="margin: 0px;padding: 0px;">
        <label for="name" style="width: 70%;">是否可签到:</label>
		<select name="signin_or" class="controla" style="width: 30%;">
		<option value="<?php echo $signin_or?>">
		<?php echo $signin_or?>
		</option>
		<option value="<?php if ($signin_or=='true'){echo 'false';}else {echo 'true';}?>">
		<?php if ($signin_or=='true'){echo 'false';}else {echo 'true';}?>
		</option>
        </select></br></br>
        
        <label for="name" style="width: 70%;">设置签到经验(次):</label>
		<input type="text" class="controla" name="signin_exp" value="<?php echo $signin_exp?>"  id="" style="width: 30%;"></br></br>
		 <label for="name" style="width: 70%;">设置签到iB(次):</label>
		<input type="text" class="controla" name="signin_ib" value="<?php echo $signin_ib?>"  id="" style="width: 30%;"></br></br>
		</table></br>
		<input type="submit" class="btn btn-primary btn-block" name="submit" value="保存设置">
		</form>
		
</div>
</div>
</div>
</div>
</body>
</html>
<?php 
}else {
    $data=array(
        "signin_or"=>$_POST['signin_or'],
        "signin_exp"=>$_POST['signin_exp'],
        "signin_ib"=>$_POST['signin_ib']
    );
    if(update_user_config('../../config/user_log_configs.php', $data)){
        history('修改成功');
    }else {
        history('修改失败');
    }
    
    
    
}










?>