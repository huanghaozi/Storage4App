<?php
require_once '../../include.php';
date_default_timezone_set('PRC');
$time = date("Y-m-d H:i:s");
$a = '+' . $info_date . ' ' . 'seconds';
$date = date("Y-m-d H:i:s", strtotime($a));
$ip = getip();
if ($info_or == 'true') {
    if (if_post() == '1') {
        $name = filter($_POST['name']);
        $content = filter($_POST['content']);
        $sql = "select * from info where ip = '$ip' ORDER BY id DESC LIMIT 1";
        $row = one($sql);
        if ($row && is_array($row) && ! empty($row)) {
            $newtime = $row['time'];
            if (strtotime($time) > strtotime($newtime)) {
                $sql = "insert into info (name,content,ip,date,time) values ('$name','$content','$ip','$time','$date')";
                km($sql);
                info_0('提交信息成功');
            } else {
                exit(info_1("您提交太频繁啦"));
            }
        } else {
            $sql = "insert into info (name,content,ip,date,time) values ('$name','$content','$ip','$time','$date')";
            km($sql);
            info_0('提交信息成功');
        }
    } else {
        exit(info_1("参数不可为空"));
    }
} else {
    exit(info_1("留言信息已关闭,请联系管理员"));
}

function if_post()
{
    $t = array_keys(array_map('trim', $_POST), '');
    if ($t) {
        return 0;
    } else {
        return 1;
    }
}

function info_0($info)
{
    $arr = array(
        'msg' => 0,
        'info' => $info
    );
    echo json_encode($arr, JSON_UNESCAPED_UNICODE);
}

function info_1($info)
{
    $arr = array(
        'msg' => 1,
        'info' => $info
    );
    echo json_encode($arr, JSON_UNESCAPED_UNICODE);
}