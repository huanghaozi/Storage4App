<?php
header("Content-type: text/html; charset=utf-8");
require_once '../../include.php';
admin(1);
$title=$_POST['title'];
$content=$_POST['content'];
if ($_REQUEST['cat']=='mtd'){
    $id=$_POST['id'];
    $sql = "update text set title='{$title}',text='{$content}' WHERE id='$id'";
    alert(insert($sql,"修改"), 'text_list.php');
}else {
$sql="insert into text (title,text) values ('$title','$content')";
history(insert($sql,'新增')); 
}