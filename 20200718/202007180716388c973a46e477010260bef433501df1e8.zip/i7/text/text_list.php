<?php
require_once '../../include.php';
admin(1);
$sql = "select * from text";
$text=all($sql);
if ($text==false){
    history("当前还没有数据");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>i7网络验证</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="../../css/layui.css"/>
	<link rel="stylesheet" type="text/css" href="../../css/boostrap.css"/>
<style type="text/css">
	body
	{
		margin: 0;
		padding: 20px;
		color: #000;
		background: #fff;
		font: 100%/1.3 helvetica, arial, sans-serif;
	}
	
	h1 { margin: 0; }
	.container { width: 100%; }
	
	table
	{
		margin: 0;
		border-collapse: collapse;
	}
	
	td, th
	{
		padding: .5em 1em;
		border: 1px solid #999;
		white-space: nowrap;
	}
	
	.table-container
	{
		width: 100%;
		overflow-y: auto;
		_overflow: auto;
		margin: 0 0 1em;
	}
</style>
</head>
<body>
	<nav class="navbar navbar-fixed-top navbar-default">
    <div class="container">
      <div class="navbar-header">
        <span class="navbar-brand">i7网络验证</span>
      </div>
    </div>
  </nav>
  <div class="container" style="padding-top:60px;">
    <div class="col-xs-12 col-sm-8 col-lg-6 center-block" style="float: none;">

<div class="panel panel-primary">
	<div class="panel-heading">
		<h3 class="panel-title" align="center">自定义文档</h3>
	</div>
	<div class="panel-body">
<div class="container">
	<div class="table-container">
	<center>
		<table>
			<tr>
				<th>标题</th>
				<th>操作</th>
			</tr>
			<tr>
  <?php while($row = mysqli_fetch_assoc($text)) {?>
    <td><?php echo $row['title']?></td>
    <td>
    <button type="button" class="layui-btn layui-btn-xs layui-btn-warm" onclick="location.href='text_op.php?cat=mtd&id=<?php echo $row['id'].'&title='.$row['title'].'&text='.$row['text']?>'">修改</button>
    <button type="button" class="layui-btn layui-btn-xs layui-btn-danger" onclick="location.href='text_op.php?cat=del&id=<?php echo $row['id']?>'">删除</button>
    <button type="button" class="layui-btn layui-btn-xs" onclick="location.href='text_op.php?cat=call&id=<?php echo $row['id']?>'">调用</button>
    </td>
  </tr>
  <?php } ?>
    </table>
       </center>
   </div>
   </div>


</div>
</div>
<script type="text/javascript" src="http://tajs.qq.com/stats?sId=15910806" charset="UTF-8"></script>
</body>
</html>
