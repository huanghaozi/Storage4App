<?php
require_once '../../include.php';
admin(1);
?>


<html lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="viewport" content="initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0,user-scalable=no,minimal-ui">
<title>i7网络验证</title>
<link rel="stylesheet" type="text/css" href="../../css/boostrap.css"/>
<style type="text/css">
	.inputDiv {
  font-size: 0;
}
</style>
</head>
<body>
<nav class="navbar navbar-fixed-top navbar-default">
    <div class="container">
      <div class="navbar-header">
        <span class="navbar-brand">i7网络验证</span>
      </div>
    </div>
  </nav>
  <div class="container" style="padding-top:60px;">
    <div class="col-xs-12 col-sm-8 col-lg-6 center-block" style="float: none;">

<div class="panel panel-primary">
	<div class="panel-heading">
		<h3 class="panel-title" align="center">自定义文档</h3>
	</div>
	<div class="panel-body">
		<form action="text_add.php?cat=in"  method="post">
		<label for="name">文档标题:</label>
		<input type="text" class="form-control" name="title" value="" placeholder="请输入标题" id="title">
		<label for="name">文档内容:</label>
		<textarea rows="5" class="form-control" name="content"  placeholder="请输入内容" cols="30"></textarea>
		<br><input type="submit" class="btn btn-primary btn-block" value="添加文档">
		</form>
		<input type="submit" class="btn btn-primary btn-block" name="submit" value="查看文档" onclick='location.href=("./text_list.php")'>
		<input type="submit" class="btn btn-primary btn-block" name="Submit" onclick="javascript:history.back(-1);" value="返回上一页"><br>
</div>
</div>
</div>
</div>
</body>
</html>