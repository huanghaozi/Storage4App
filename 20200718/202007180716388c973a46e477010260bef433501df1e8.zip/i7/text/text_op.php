<?php
header("Content-type: text/html; charset=utf-8");
require_once '../../include.php';
$cat=$_GET['cat'];
$id=$_GET['id'];
if ($cat=='mtd'){
    admin(1);
    ?>
    <html lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="viewport" content="initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0,user-scalable=no,minimal-ui">
<title>i7网络验证</title>
<link rel="stylesheet" type="text/css" href="../../css/boostrap.css"/>
<style type="text/css">
	.inputDiv {
  font-size: 0;
}
</style>
</head>
<body>
<nav class="navbar navbar-fixed-top navbar-default">
    <div class="container">
      <div class="navbar-header">
        <span class="navbar-brand">i7网络验证</span>
      </div>
    </div>
  </nav>
  <div class="container" style="padding-top:60px;">
    <div class="col-xs-12 col-sm-8 col-lg-6 center-block" style="float: none;">

<div class="panel panel-primary">
	<div class="panel-heading">
		<h3 class="panel-title" align="center">自定义文档</h3>
	</div>
	<div class="panel-body">
		<form action="text_add.php?cat=mtd"  method="post">
		<label for="name">文档ID:</label>
		<input type="text" class="form-control" name="id" value="<?php echo $_GET['id']?>" placeholder="" id="" readonly="readonly">
		<label for="name">文档标题:</label>
		<input type="text" class="form-control" name="title" value="<?php echo $_GET['title']?>" placeholder="请输入标题" id="title">
		<label for="name">文档内容:</label>
		<textarea rows="5" class="form-control" name="content"  placeholder="请输入内容" cols="30"><?php echo $_GET['text']?></textarea>
		<br><input type="submit" class="btn btn-primary btn-block" value="修改文档">
		</form>
		<input type="submit" class="btn btn-primary btn-block" name="submit" value="查看文档" onclick='location.href=("./text_list.php")'>
</div>
</div>
</div>
</div>
</body>
</html>
    
<?php     
}elseif ($cat=='del'){
    $sql = "delete from text where id='$id'";
    history(insert($sql,"删除"));
}elseif ($cat=='call'){
    $uid=filter($id);
    if ($uid==$id &&  $id!=null && is_numeric($id) &&$id!=0){
        $sql = "select * from text where id=$uid";
        $text=all($sql);
        if ($text==false){
            echo '参数错误';
        }else {
            while($row = mysqli_fetch_assoc($text)){
                echo $row['title'].'<br>'.$row['text'].'<br><br><br><br><br><br><br>';
                echo 't()<br>{<br>s a = "http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'].'"<br>hs(a, b)<br>syso(b)<br>}';
            }
        }
       
    }else {
        echo '参数错误';
    }
}

?>