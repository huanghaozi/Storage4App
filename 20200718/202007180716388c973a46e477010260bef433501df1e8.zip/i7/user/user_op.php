<?php
header("Content-type: text/html; charset=utf-8");
require_once '../../include.php';
admin(1);
$cat=$_GET['cat'];
$id=$_GET['id'];
$sql = "select * from user where id=$id";
$row=one($sql);
if ($cat=='mtd'){
    ?>
    <html lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="viewport" content="initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0,user-scalable=no,minimal-ui">
<title>i7网络验证</title>
<link rel="stylesheet" type="text/css" href="../../css/boostrap.css"/>
<style type="text/css">
	.inputDiv {
  font-size: 0;
}
</style>
</head>
<body>
<nav class="navbar navbar-fixed-top navbar-default">
    <div class="container">
      <div class="navbar-header">
        <span class="navbar-brand">i7网络验证</span>
      </div>
    </div>
  </nav>
  <div class="container" style="padding-top:60px;">
    <div class="col-xs-12 col-sm-8 col-lg-6 center-block" style="float: none;">

<div class="panel panel-primary">
	<div class="panel-heading">
		<h3 class="panel-title" align="center">自定义文档</h3>
	</div>
	<div class="panel-body">
		<form action="user_add.php"  method="post">
		<label for="name">用户ID:</label>
		<input type="text" class="form-control" name="user_id" value="<?php echo $row['user_id']?>"  readonly="readonly">
		<label for="name">用户名:</label>
		<input type="text" class="form-control" name="user_name" value="<?php echo $row['user_name']?>" >
		<label for="name">用户密码:</label>
		<input type="text" class="form-control" name="user_pass" value="<?php echo $row['user_pass1']?>" >
		<label for="name">用户邮箱:</label>
		<input type="text" class="form-control" name="user_email" value="<?php echo $row['user_email']?>" >
		<label for="name">邮箱是否激活:</label>
		<input type="text" class="form-control" name="email_or" value="<?php echo $row['email_or']?>" >
		<label for="name">账号状态:</label>
		<input type="text" class="form-control" name="state" value="<?php echo $row['state']?>" readonly="readonly">
		<label for="name">邀请码:</label>
		<input type="text" class="form-control" name="i_code" value="<?php echo $row['i_code']?>" >
		<label for="name">账号ib:</label>
		<input type="text" class="form-control" name="ib" value="<?php echo $row['ib']?>" >
		<label for="name">账号经验:</label>
		<input type="text" class="form-control" name="exp" value="<?php echo $row['exp']?>" >
		<label for="name">账号VIP:</label>
		<input type="text" class="form-control" name="vip" value="<?php echo $row['vip']?>" >
		<label for="name">VIP到期时间:</label>
		<input type="text" class="form-control" name="vip_enddate" value="<?php echo $row['vip_enddate']?>" >
		<label for="name">签到次数:</label>
		<input type="text" class="form-control" name="signin" value="<?php echo $row['signin']?>" >
		<label for="name">最近一次签到时间:</label>
		<input type="text" class="form-control" name="signin_date" value="<?php echo $row['signin_date']?>" readonly="readonly">
		<label for="name">注册IP:</label>
		<input type="text" class="form-control" name="ip" value="<?php echo $row['ip']?>" readonly="readonly">
		<label for="name">注册时间:</label>
		<input type="text" class="form-control" name="time" value="<?php echo $row['time']?>" readonly="readonly">
		<br><input type="submit" class="btn btn-primary btn-block" value="一键修改">
		</form>
		<input type="submit" class="btn btn-primary btn-block" name="submit" value="查看用户" onclick='location.href=("./user_list.php")'>
</div>
</div>
</div>
</div>
</body>
</html>
    
<?php     
}elseif ($cat=='del'){
    $sql = "delete from user where id='$id'";
    history(insert($sql,"删除"));
}elseif ($cat=='state'){
    if ($_GET['state']=='白名单'){
    $sql = "update user set state='黑名单' WHERE id='$id'";
    history(insert($sql,"已拉黑"));
    }else {
        $sql = "update user set state='白名单' WHERE id='$id'";
        history(insert($sql,"已取消"));
    }
}

?>