<?php
date_default_timezone_set("PRC");
ob_start();
require_once '../../../include.php';
require './PHPMailer/class.phpmailer.php';
require './PHPMailer/class.smtp.php';
require './email.php';
ob_end_clean();
if (strcmp($_POST['act'], "red") == 0) {
    if (user_key()==0){
        exit(info_1('密匙错误'));
    }
    api_red();
} elseif (strcmp($_POST['act'], "login") == 0) {
    if (user_key()==0){
        exit(info_1('密匙错误'));
    }
    api_login();
}elseif (strcmp($_POST['act'], "modify") == 0) {
    if (user_key()==0){
        exit(info_1('密匙错误'));
    }
    api_modify();
}elseif (strcmp($_POST['act'], "pass") == 0) {
    if (user_key()==0){
        exit(info_1('密匙错误'));
    }
    api_pass();
}elseif (strcmp($_POST['act'], "signin") == 0) {
    if (user_key()==0){
        exit(info_1('密匙错误'));
    }
    api_signin();
}elseif (strcmp($_POST['act'], "query") == 0) {
    echo api_query();
    
}elseif (strcmp($_POST['act'], "exp") == 0) {
    if (user_key()==0){
        exit(info_1('密匙错误'));
    }
    echo api_exp();
}elseif (strcmp($_POST['act'], "ib") == 0) {
    if (user_key()==0){
        exit(info_1('密匙错误'));
    }
    echo api_ib();
}elseif (strcmp($_POST['act'], "cal") == 0) {
    echo api_cal();
}elseif (strcmp($_POST['act'], "rank") == 0) {
    echo api_rank();
}
/**
 * 风云榜(rank)排行
 */
function api_rank(){
    if (if_post()==1){
        //判断rank操作标识
        switch ($_POST['op']){
            case "exp":
                rank_exp();
                break;
            case "ib":
                rank_ib();
                break;
            case "signin":
                rank_signin();
                break;
            default:
                info_1("标识错误");
        }
    }else {exit(info_1("参数不可为空"));}
}

/**
 * 签到排行榜
 */
function rank_signin(){
    $sql="SELECT * FROM user ORDER BY signin DESC limit 10";
    $row=all($sql);
    $all=array();
    if ($row!=false){
        while ($ros=mysqli_fetch_assoc($row)){
            $all[]='用户:'.$ros['user_name'].'--签到:'.$ros['signin'];
        }
        info_0($all);
    }else {exit(info_1("未查询到签到排行榜"));}
}

/**
 * ib排行榜
 */
function rank_ib(){
    $sql="SELECT * FROM user ORDER BY ib DESC limit 10";
    $row=all($sql);
    $all=array();
    if ($row!=false){
        while ($ros=mysqli_fetch_assoc($row)){
            $all[]='用户:'.$ros['user_name'].'--iB:'.$ros['ib'];
        }
        info_0($all);
    }else {exit(info_1("未查询到iB排行榜"));}
}

/**
 * 经验排行榜
 */
function rank_exp(){
    $sql="SELECT * FROM user  ORDER BY exp DESC limit 10";
    $row=all($sql);
    $all=array();
    if ($row!=false){
        while ($ros=mysqli_fetch_assoc($row)){
            $all[]='用户:'.$ros['user_name'].'--经验:'.$ros['exp'];
        }
        info_0($all);
    }else {exit(info_1("未查询到经验排行榜"));}
}


/**
 * 邀请查询
 */
function api_cal(){
    if (if_post()==1){
        $user_id=$_POST['user_id'];
        $user_id1=filter($_POST['user_id']);
        if ($user_id==$user_id1){
            $sql = "select * from user where user_id = '$user_id'";
            $row=one($sql);
            if ($row && is_array($row) && !empty($row)){
                $cal=$row['i_code'];
                $sql = "select * from user where i_cal = '$cal'";
                $ros=all($sql);
                if ($ros!=false){
                    while($rows = mysqli_fetch_assoc($ros)){
                        $name =$rows['user_name'].'--'.$name;
                    }
                    $arr=array(
                        '当前账号'=>$user_id,
                        '已邀请人数'=>mysqli_num_rows($ros),
                        '邀请用户'=>$name
                    );
                    info_0($arr);
                }else {
                    $arr=array(
                        '当前账号'=>$user_id,
                        '已邀请人数'=>0,
                        '邀请用户'=>'null'
                    );
                    info_0($arr);
                }
            }else {exit(info_1('未查询到此账号'));}
        }else {exit(info_1('数据不匹配'));}
    }else {exit(info_1("参数不可为空"));}
    
    
}

/**
 * ib加减
 */
function api_ib(){
    //判断ib操作标识
    $num=$_POST['num'];
    $user_id=$_POST['user_id'];
    $num=abs($_POST['num']);
    $user_id=$_POST['user_id'];
    switch ($_POST['op']){
        case "a":
            api_ib_a($num,$user_id);
            break;
        case "r":
            api_ib_r($num,$user_id);
            break;
        default:
            info_1("标识错误");
    }
}

/**
 * ib增加
 * @param unknown $num
 * @param unknown $user_id
 */
function api_ib_a($num,$user_id){
    if (post_filter()==1){
        if (if_post()==1){
            if (user_correct()[0]==1){
                $sql="update user set ib=ib+$num where user_id = '$user_id'";
                echo user_exp($sql);
            }else {exit(info_1("账号或者密码错误"));}
        }else {exit(info_1("参数不可为空"));}
    }else {exit(info_1("数据不匹配"));}
}

/**
 * id减少--判断用户ib是否充足
 * @param unknown $num
 * @param unknown $user_id
 */
function api_ib_r($num,$user_id){
    if (post_filter()==1){
        if (if_post()==1){
            if (user_correct()[0]==1){
                if (user_correct()[1]['ib']-$num>=0){
                    $sql="update user set ib=ib-$num where user_id = '$user_id'";
                    echo user_exp($sql);
                }else {exit(info_1("当前账户余额不足,请充值!"));}
            }else {exit(info_1("账号或者密码错误"));}
        }else {exit(info_1("参数不可为空"));}
    }else {exit(info_1("数据不匹配"));}
}

/**
 * 经验加减
 */
function api_exp(){
    //判断exp操作标识
    $num=$_POST['num'];
    $user_id=$_POST['user_id'];
    $num=abs($_POST['num']);
    $user_id=$_POST['user_id'];
    switch ($_POST['op']){
        case "a":
            api_exp_a($num,$user_id);
            break;
        case "r":
            api_exp_r($num,$user_id);
            break;
        default:
            info_1("标识错误");
    }
}


/**
 * 经验增加
 * @param unknown $num
 * @param unknown $user_id
 */
function api_exp_a($num,$user_id){
    if (post_filter()==1){
        if (if_post()==1){
            if (user_correct()[0]==1){
                $sql="update user set exp=exp+$num where user_id = '$user_id'";
                echo user_exp($sql);
            }else {exit(info_1("账号或者密码错误"));}
        }else {exit(info_1("参数不可为空"));}
    }else {exit(info_1("数据不匹配"));}
}

/**
 * 经验减少
 * @param unknown $num
 * @param unknown $user_id
 */
function api_exp_r($num,$user_id){
    if (post_filter()==1){
        if (if_post()==1){
            if (user_correct()[0]==1){
                $sql="update user set exp=exp-$num where user_id = '$user_id'";
                echo user_exp($sql);
            }else {exit(info_1("账号或者密码错误"));}
        }else {exit(info_1("参数不可为空"));}
    }else {exit(info_1("数据不匹配"));}
}

/**
 * 判断账号是否存在
 * @return unknown
 */
function user_correct(){
    $user_id=$_POST['user_id'];
    $user_pass = md5($_POST['user_pass'].$user_id);
    $sql = "select * from user where user_id = '$user_id' and user_pass='$user_pass'";
    $row=one($sql);
    if ($row && is_array($row) && !empty($row)){
        return array(1,$row);
    }else {
        return array(0,null);
    }
}

/**
 * 判断参数是否为空
 * @return number
 */
function if_post(){
    $t=array_keys(array_map('trim',$_POST),'');
    if ($t){
        return 0;
    }else {
        return 1;
    }
}


/**
 * POST参数过滤
 */
function post_filter(){
    $user_id=$_POST['user_id'];
    $user_pass=$_POST['user_pass'];
    $user_id1=filter($_POST['user_id']);
    $user_pass1=filter($_POST['user_pass']);
    if ($user_id==$user_id1 && $user_pass==$user_pass1){
        return 1;
    }else {
        return 0;
    }
}

/**
 * 检测用户_id长度
 * @param unknown $POST
 * @return number
 */
function user_length(){
    global $user_s,$user_b;
    $length=strlen($_POST['user_id']);
    if ($user_s<=$length&&$length<=$user_b){
        return 0;
    }else {
        return 1;
    }
}


/**
 * 检测key
 * @param unknown $POST
 * @return number
 */
function user_key(){
    global $key_or,$key_cheng,$key_chu;
    if ($key_or == 'true'){
        $a=date("YmdHis");
        $x= $a*$key_cheng/$key_chu-2;
        $y= $a*$key_cheng/$key_chu+2;
        if (empty($_POST['key'])){
            return 0;
        }else{
            $key=$_POST['key'];
            if ($x<=$key&&$key<=$y){
                return 1;
            }else {
                return 0;
            }
        }
    }else {
        return 1;
    }
}



/**
 * 账号注册
 * @param unknown $POST
 */
function api_red(){
    global $user_log_or,$user_log_vip_or,$user_log_vip_date,$user_email_or,$key_or,$key_cheng,$key_chu;
    // 判断act类型
    if ($user_log_or == 'true') {
        // 判断注册通道是否关闭
        $user_id = filter($_POST['user_id']);
        if (empty($_POST['user_id']) || empty($_POST['user_pass']) || empty($_POST['user_name']) || empty($_POST['user_email']) || $user_id != $_POST['user_id']) {
            // 判断参数完整性
            info_1('数据不匹配');
        } else {
            if (user_length()==1){
                exit(info_1("长度不匹配"));
            }
            $user_name = $_POST['user_name'];
            $i_code = rand(10000, 999999);
            $ip = getip();
            $a = '+' . $user_log_vip_date . ' ' . 'day';
            $date_end = date("Y-m-d H:i:s", strtotime($a));
            $user_pass = md5($_POST['user_pass'].$user_id);
            $user_pass1=$_POST['user_pass'];
            $user_email = $_POST['user_email'];
            $time=date("Y-m-d H:i:s");
            $i_cal = $_POST['i_cal'];
            $sql = "select * from user where user_id =$user_id";
            if (num($sql)>0) {
                exit(info(2));
            }else {
                $sql = "select * from user where user_name='$user_name'";
                if (num($sql)>0){
                    exit(info(2));
                }
            }
            if ($user_email_or == 'false') {
                if ($user_log_vip_or == 'true') {
                    $sql = "insert into user (user_id,user_pass,user_pass1,user_name,user_email,i_code,i_cal,vip,vip_enddate,ip,time) values ('$user_id','$user_pass','$user_pass1','$user_name','$user_email','$i_code','$i_cal','true','$date_end','$ip','$time')";
                } else {
                    $sql = "insert into user (user_id,user_pass,user_pass1,user_name,user_email,i_code,i_cal,ip,time) values ('$user_id','$user_pass','$user_pass1','$user_name','$user_email','$i_code','$i_cal','$ip','$time')";
                }
                echo red($sql);
            } else {
                if ($user_log_vip_or == 'true') {
                    $sql = "insert into user (user_id,user_pass,user_pass1,user_name,user_email,email_or,i_code,i_cal,vip,vip_enddate,ip,time) values ('$user_id','$user_pass','$user_pass1','$user_name','$user_email','false','$i_code','$i_cal','true','$date_end','$ip','$time')";
                } else {
                    $sql = "insert into user (user_id,user_pass,user_pass1,user_name,user_email,email_or,i_code,i_cal,ip,time) values ('$user_id','$user_pass','$user_pass1','$user_name','$user_email','false','$i_code','$i_cal','$ip','$time')";
                }
                echo red_email($sql, $user_id, $user_email, 'http://'.$_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"]);
            }
        }
    } else {
        info(3);
    }
}

/**
 * 判断邮箱是否验证
 * @param unknown $email_or
 * @return boolean
 */
function email_or($email_or){
    if ($email_or=='true'){
        return true;
    }else {
        return false;
    }
}

/**
 * 判断账号状态是否可以登录
 * @param unknown $state
 * @return boolean
 */
function user_state($state){
    if ($state=="白名单"){
        return true;
    }else {
        return false;
    }
}

/**
 * 检测用户等级
 * @param unknown $exp
 * @return string
 */
function lv_name($exp){
    global $user_lv1_name,$user_lv2_name,$user_lv3_name,$user_lv1_exp,$user_lv2_exp,$user_lv3_exp;
    if ($exp<$user_lv1_exp){
        return $user_lv1_name;
    }elseif ($user_lv1_exp<$exp && $exp<$user_lv2_exp){
        return $user_lv1_name;
    }elseif ($user_lv2_exp<=$exp && $exp<$user_lv3_exp){
        return $user_lv2_name;
    }elseif ($exp>=$user_lv3_exp){
        return $user_lv3_name;
    }
    
}

/**
 * 用户登录
 */
function api_login(){
    $user_id=$_POST['user_id'];
    $user_pass=$_POST['user_pass'];
    $user_id1=filter($_POST['user_id']);
    $user_pass1=filter($_POST['user_pass']);
    if ($user_id==$user_id1 && $user_pass==$user_pass1){
        $user_pass=md5($user_pass.$user_id);
        $sql = "select * from user where user_id = '$user_id' and user_pass='$user_pass'";
        $row=one($sql);
        if ($row && is_array($row) && !empty($row)){
            if (email_or($row['email_or'])){
                if (user_state($row['state'])){
                    $user_info=array(
                        '用户名'=>$row['user_name'],
                        '用户账号'=>$row['user_id'],
                        '用户邮箱'=>$row['user_email'],
                        '邀请码'=>$row['i_code'],
                        'iB'=>$row['ib'],
                        '等级称号'=>lv_name($row['exp']),
                        '用户账号经验'=>$row['exp'],
                        'vip'=>$row['vip'],
                        'vip到期时间'=>$row['vip_enddate'],
                        '签到次数'=>$row['signin'],
                        '最后一次签到时间'=>$row['signin_date'],
                        '注册时间'=>$row['time'],
                    );
                    info_0($user_info);
                }else {info_1('账号已封禁,请联系管理员');}
            }else {info_1('账号未激活,请前往邮箱验证');}
        }else {info_1('账号或密码错误');}
    }else {info_1('数据不匹配');}
}


/**
 * 修改用户密码和email
 * @param unknown $POST
 */
function api_modify(){
    if ($_POST['new_user_pass']=='' || $_POST['new_user_email']==''){
        info_1('数据不可为空');
    }else {
        $user_id=$_POST['user_id'];
        $user_pass=$_POST['user_pass'];
        $user_id1=filter($_POST['user_id']);
        $user_pass1=filter($_POST['user_pass']);
        if ($user_id==$user_id1 && $user_pass==$user_pass1){
            $user_pass=md5($user_pass.$user_id);
            $sql = "select * from user where user_id = '$user_id' and user_pass='$user_pass'";
            $row=one($sql);
            if ($row && is_array($row) && !empty($row)){
                if ($row['user_id']==$user_id && $row['user_pass']==$user_pass){
                    $user_id=$_POST['user_id'];
                    $new_user_pass=md5($_POST['new_user_pass'].$_POST['user_id']);
                    $new_user_email=$_POST['new_user_email'];
                    $user_pass=$_POST['user_pass'];
                    $sql = "update user set user_pass='{$new_user_pass}',user_pass1='{$user_pass}',user_email='{$new_user_email}' WHERE user_id='$user_id'";
                    insert($sql, "修改");
                    info_0("修改成功");
                }else {info_1('账号或密码错误');}
            }else {info_1('数据不匹配');}
        }else {info_1('数据不匹配');}
    }
}

/**
 * 用户找回密码
 * @param unknown $POST
 */
function api_pass(){
    $user_id=$_POST['user_id'];
    $user_email=$_POST['user_email'];
    $user_id1=filter($_POST['user_id']);
    if ($user_id==$user_id1){
        $sql = "select * from user where user_id = '$user_id' and user_email = '$user_email'";
        $row=one($sql);
        if ($row && is_array($row) && !empty($row)){
            $pass=$row['user_pass1'];
            sendMail($user_email, 'i7网络验证', "i7网络验证提醒你:\r\n你正在找回密码,若不是本来操作,请尽快联系管理员\r\n你的密码为:".$pass);
            info_0('密码找回成功,请前往邮箱查看--若非本人操作,请尽快联系管理员');
        }else {info_1('数据不存在');}
    }else {info_1('数据不匹配');}
}

/**
 * 用户签到
 * @param unknown $POST
 */
function api_signin(){
    global $signin_exp,$signin_ib,$ib;
    $user_id=$_POST['user_id'];
    $user_pass=$_POST['user_pass'];
    $date=date("Y-m-d");
    $user_pass=md5($user_pass.$user_id);
    $user_id1=filter($_POST['user_id']);
    if ($user_id==$user_id1){
        $sql = "select * from user where user_id = '$user_id' and user_pass='$user_pass'";
        $row=one($sql);
        if ($row && is_array($row) && !empty($row)){
            $sql = "select * from user where user_id = '$user_id' and user_pass='$user_pass' and signin_date='$date'";
            $row=one($sql);
            if ($row && is_array($row) && !empty($row)){
                info_1('今日已签到,改天再来吧!');
            }else {
                $sql="update user set exp=exp+$signin_exp,ib=ib+$signin_ib,signin=signin+1,signin_date='$date' where user_id = '$user_id'";
                echo signin($sql);
            }
        }else {info_1('账号或密码错误');}
    }else {info_1('数据不匹配');}
}

/**
 * 查询用户信息
 */
function api_query(){
    $time=date("y-m-d");
    $user_id=$_POST['user_id'];
    $user_id1=filter($_POST['user_id']);
    if ($user_id==$user_id1){
        $sql = "select * from user where user_id = '$user_id'";
        $row=one($sql);
        if ($row && is_array($row) && !empty($row)){
            if ($row['vip']=='true'){
                if (strtotime($time)<=strtotime($row['vip_enddate'])){
                }else {
                    $upsql="update user set vip='false',vip_enddate='null' WHERE user_id='$user_id'";
                    km($upsql);
                    $user_info=array(
                        '用户名'=>$row['user_name'],
                        '用户账号'=>$row['user_id'],
                        '邀请码'=>$row['i_code'],
                        'iB'=>$row['ib'],
                        '等级称号'=>lv_name($row['exp']),
                        '用户账号经验'=>$row['exp'],
                        'vip'=>'false',
                        'vip到期时间'=>'',
                        '签到次数'=>$row['signin'],
                        '最后一次签到时间'=>$row['signin_date'],
                        '注册时间'=>$row['time'],
                    );
                    info_0($user_info);
                }
            }else {
                $user_info=array(
                    '用户名'=>$row['user_name'],
                    '用户账号'=>$row['user_id'],
                    '邀请码'=>$row['i_code'],
                    'iB'=>$row['ib'],
                    '用户账号经验'=>$row['exp'],
                    'vip'=>$row['vip'],
                    'vip到期时间'=>$row['vip_enddate'],
                    '签到次数'=>$row['signin'],
                    '最后一次签到时间'=>$row['signin_date'],
                    '注册时间'=>$row['time'],
                );
                info_0($user_info);
            }
        }else {info_1('账号不存在');}
    }else {info_1('数据不匹配');}
}


/**
 * 返回信息
 * @param unknown $msg
 */
function info($msg){
    switch ($msg)
    {
        case 0:
            $arr = array(
            'msg' => 0,
            'info' => '注册成功'
                );
            echo json_encode($arr,JSON_UNESCAPED_UNICODE);
            break;
        case 2:
            $arr = array(
            'msg' => 2,
            'info' => '用户ID或用户名已存在'
                );
            echo json_encode($arr,JSON_UNESCAPED_UNICODE);
            break;
        case 3:
            $arr = array(
            'msg' => 3,
            'info' => '注册已关闭'
                );
            echo json_encode($arr,JSON_UNESCAPED_UNICODE);
            break;
        case 4:
            $arr = array(
            'msg' => 4,
            'info' => '注册成功,请邮箱激活'
                );
            echo json_encode($arr,JSON_UNESCAPED_UNICODE);
            break;
        case 5:
            $arr = array(
            'msg' => 5,
            'info' => '参数不完整'
                );
            echo json_encode($arr,JSON_UNESCAPED_UNICODE);
            break;
    }
}
/**
 * 返回错误信息
 * @param unknown $info
 */
function info_1($info){
    $arr = array(
        'msg' => 1,
        'info' => $info,
    );
    echo json_encode($arr,JSON_UNESCAPED_UNICODE);
}
function info_0($info){
    $arr = array(
        'msg' => 0,
        'info' => $info,
    );
    echo json_encode($arr,JSON_UNESCAPED_UNICODE);
}


function red_email($sql,$user_id,$user_email,$url){
    $link=connect();
    if (mysqli_query($link,$sql)){
        $arr = array(
            'msg' => 4,
            'info' => '注册成功,请邮箱激活'
        );
        $info= json_encode($arr,JSON_UNESCAPED_UNICODE);
        sendMail($user_email,'账号激活通知','尊敬的用户你好,你的激活链接为:'.dirname($url).'/api_email.php?user_id='.$user_id);
        return $info;
    }else {
        $arr = array(
            'msg' => 6,
            'info' => '注册失败,系统错误'
        );
        $info= json_encode($arr,JSON_UNESCAPED_UNICODE);
        return $info;
    }
    mysqli_close($link);
}
