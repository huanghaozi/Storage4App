<?php
require_once '../../../include.php';
admin(1);
?>


<html lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="viewport" content="initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0,user-scalable=no,minimal-ui">
<title>i7网络验证</title>
<link rel="stylesheet" type="text/css" href="../../../css/boostrap.css"/>
<style type="text/css">
	.inputDiv {
  font-size: 0;
}
</style>
</head>
<body>
<nav class="navbar navbar-fixed-top navbar-default">
    <div class="container">
      <div class="navbar-header">
        <span class="navbar-brand">i7网络验证</span>
      </div>
    </div>
  </nav>
  <div class="container" style="padding-top:60px;">
    <div class="col-xs-12 col-sm-8 col-lg-6 center-block" style="float: none;">

<div class="panel panel-primary">
	<div class="panel-heading">
		<h3 class="panel-title" align="center">调用文档</h3>
	</div>
	<div class="panel-body">
		<input type="submit" class="btn btn-primary btn-block" name="Submit" onclick="javascript:history.back(-1);" value="返回上一页"><br>
		<input type="submit" class="btn btn-primary btn-block" name="submit" value="注册" onclick='location.href=("api_help.php?act=注册")'>
		<input type="submit" class="btn btn-primary btn-block" name="submit" value="登录" onclick='location.href=("api_help.php?act=登录")'>
		<input type="submit" class="btn btn-primary btn-block" name="submit" value="修改信息" onclick='location.href=("api_help.php?act=修改")'>
		<input type="submit" class="btn btn-primary btn-block" name="submit" value="找回密码" onclick='location.href=("api_help.php?act=找回密码")'>
		<input type="submit" class="btn btn-primary btn-block" name="submit" value="用户签到" onclick='location.href=("api_help.php?act=用户签到")'>
		<input type="submit" class="btn btn-primary btn-block" name="submit" value="用户信息" onclick='location.href=("api_help.php?act=用户信息")'>
		<input type="submit" class="btn btn-primary btn-block" name="submit" value="邀请查询" onclick='location.href=("api_help.php?act=邀请查询")'>
		<input type="submit" class="btn btn-primary btn-block" name="submit" value="经验加减" onclick='location.href=("api_help.php?act=经验加减")'>
		<input type="submit" class="btn btn-primary btn-block" name="submit" value="iB加减" onclick='location.href=("api_help.php?act=iB加减")'>
		<input type="submit" class="btn btn-primary btn-block" name="submit" value="风云榜" onclick='location.href=("api_help.php?act=风云榜")'>
</div>
</div>
</div>
</div>

</body>
<script type="text/javascript">
	function aa(){
    document.getElementById('code').src="./code.php?"+Math.random();
}
</script>
</html>