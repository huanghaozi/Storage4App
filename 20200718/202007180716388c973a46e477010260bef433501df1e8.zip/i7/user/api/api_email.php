<?php
require_once '../../../include.php';
$user_id=$_GET['user_id'];
$sql = "select * from user where user_id = '$user_id'";
$row=one($sql);
if ($row && is_array($row) && !empty($row)){
    if ($row['email_or']=='true'){
        exit('你的账号已经激活啦!');
        
    }
    $sql="update user set email_or='true' where user_id='{$user_id}'";
    km($sql);
    echo '激活成功!';
}else {
    echo '账号不存在,请联系管理员';
}