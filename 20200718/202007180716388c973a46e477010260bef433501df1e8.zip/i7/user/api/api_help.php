<?php
require_once '../../../include.php';
admin(1);
?>


<html lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport"
	content="initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0,user-scalable=no,minimal-ui">
<title>i7网络验证</title>
<link rel="stylesheet" type="text/css" href="../../../css/boostrap.css" />
<style type="text/css">
.inputDiv {
	font-size: 0;
}
</style>
</head>
<body>
	<nav class="navbar navbar-fixed-top navbar-default">
		<div class="container">
			<div class="navbar-header">
				<span class="navbar-brand">i7网络验证</span>
			</div>
		</div>
	</nav>
	<div class="container" style="padding-top: 60px;">
		<div class="col-xs-12 col-sm-8 col-lg-6 center-block"
			style="float: none;">

			<div class="panel panel-primary">
				<div class="panel-heading">
<?php 
switch ($_GET['act']){
    case '注册':
        ?>
        					<h3 class="panel-title" align="center"><?php echo $_GET['act']?>调用文档</h3>
				</div>
				<div class="panel-body">
					<input type="submit" class="btn btn-primary btn-block"
						name="Submit" onclick="javascript:history.back(-1);" value="返回上一页"><br>
					<label for="name">提交地址:</label><br>
		<?php $url='http://'.$_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"]; echo dirname($url).'/api.php';?><br>
					<br> <label for="name">返回格式:</label><br> JSON<br>
					<br> <label for="name">提交方式:</label><br> POST<br>
					<br> <label for="name">请求参数:</label><br>

					<table border="1" width="100%">
						<tr>
							<th bgcolor="#F5F5DC">参数</th>
							<th bgcolor="#F5F5DC">必填</th>
							<th bgcolor="#F5F5DC">说明</th>
						</tr>
						<tr>
							<td>act</td>
							<td>是(red)</td>
							<td>注册标识</td>
						</tr>
						<tr>
							<td>user_name</td>
							<td>是</td>
							<td>用户名</td>
						</tr>
						<tr>
							<td>user_id</td>
							<td>是</td>
							<td>用户账号</td>
						</tr>
						<tr>
							<td>user_pass</td>
							<td>是</td>
							<td>用户密码</td>
						</tr>
						<tr>
							<td>user_email</td>
							<td>是</td>
							<td>用户邮箱</td>
						</tr>
						<tr>
							<td>i_cal</td>
							<td>否</td>
							<td>邀请码</td>
						</tr>
						<tr>
							<td>key</td>
							<td>根据系统配置</td>
							<td>操作密匙</td>
						</tr>
					</table><br>
					<label for="name">返回参数:</label></br>
					<table border="1" width="100%">
						<tr>
							<th bgcolor="#F5F5DC">名称</th>
							<th bgcolor="#F5F5DC">说明</th>
						</tr>
						<tr>
							<td>msg</td>
							<td><span style="color:red"><b>0</b></span>-注册成功<br>
								<span style="color:red"><b>1</b></span>-注册失败<br>
								<span style="color:red"><b>2</b></span>-用户ID或用户名已存在<br>
								<span style="color:red"><b>3</b></span>-注册已关闭<br>
								<span style="color:red"><b>4</b></span>-注册成功,请邮箱激活<br>
								<span style="color:red"><b>5</b></span>-参数不完整<br>
								<span style="color:red"><b>6</b></span>-注册失败,系统错误<br>
							</td>
						</tr>
						<tr>
							<td>info</td>
							<td>返回信息</td>
						</tr>
					</table><br>
					<label for="name">请求事例:</label></br>
					<textarea rows="10" class="form-control" name="content"  cols="30" readonly="readonly"  wrap="hard" >
t()
{
s a = "<?php echo dirname($url).'/api.php';?>"
s post = "act=red&user_name=小i&user_id=123456&user_pass=654321&user_email=3571717467@qq.com&i_cal=147852"
hs(a, post, "utf-8", b)
syso(b)
}
					</textarea>
<?php break;?>
<?php 
    case '登录':
    ?>
    					<h3 class="panel-title" align="center"><?php echo $_GET['act']?>调用文档</h3>
				</div>
				<div class="panel-body">
					<input type="submit" class="btn btn-primary btn-block"
						name="Submit" onclick="javascript:history.back(-1);" value="返回上一页"><br>
					<label for="name">提交地址:</label><br>
		<?php $url='http://'.$_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"]; echo dirname($url).'/api.php';?><br>
					<br> <label for="name">返回格式:</label><br> JSON<br>
					<br> <label for="name">提交方式:</label><br> POST<br>
					<br> <label for="name">请求参数:</label><br>

					<table border="1" width="100%">
						<tr>
							<th bgcolor="#F5F5DC">参数</th>
							<th bgcolor="#F5F5DC">必填</th>
							<th bgcolor="#F5F5DC">说明</th>
						</tr>
						<tr>
							<td>act</td>
							<td>是(login)</td>
							<td>登录标识</td>
						</tr>
							<td>user_id</td>
							<td>是</td>
							<td>用户账号</td>
						</tr>
						<tr>
							<td>user_pass</td>
							<td>是</td>
							<td>用户密码</td>
						</tr>
						<tr>
							<td>key</td>
							<td>根据系统配置</td>
							<td>操作密匙</td>
						</tr>
					</table><br>
					<label for="name">返回参数:</label></br>
					<table border="1" width="100%">
						<tr>
							<th bgcolor="#F5F5DC">名称</th>
							<th bgcolor="#F5F5DC">说明</th>
						</tr>
						<tr>
							<td>msg</td>
							<td><span style="color:red"><b>0</b></span>-登录成功<br>
								<span style="color:red"><b>1</b></span>-登录失败<br>
							</td>
						</tr>
						<tr>
							<td>info</td>
							<td>返回信息</td>
						</tr>
					</table><br>
					<label for="name">请求事例:</label></br>
					<textarea rows="10" class="form-control" name="content"  cols="30" readonly="readonly"  wrap="hard" >
t()
{
s a = "<?php echo dirname($url).'/api.php';?>"
s post = "act=login&user_id=123456&user_pass=654321"
hs(a, post, "utf-8", b)
syso(b)
}
					</textarea>
<?php break;?>
<?php 
    case '修改':
    ?>
    					<h3 class="panel-title" align="center"><?php echo $_GET['act']?>调用文档</h3>
				</div>
				<div class="panel-body">
					<input type="submit" class="btn btn-primary btn-block"
						name="Submit" onclick="javascript:history.back(-1);" value="返回上一页"><br>
					<label for="name">提交地址:</label><br>
		<?php $url='http://'.$_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"]; echo dirname($url).'/api.php';?><br>
					<br> <label for="name">返回格式:</label><br> JSON<br>
					<br> <label for="name">提交方式:</label><br> POST<br>
					<br> <label for="name">请求参数:</label><br>

					<table border="1" width="100%">
						<tr>
							<th bgcolor="#F5F5DC">参数</th>
							<th bgcolor="#F5F5DC">必填</th>
							<th bgcolor="#F5F5DC">说明</th>
						</tr>
						<tr>
							<td>act</td>
							<td>是(modify)</td>
							<td>修改标识</td>
						</tr>
							<td>user_id</td>
							<td>是</td>
							<td>用户账号</td>
						</tr>
						<tr>
							<td>user_pass</td>
							<td>是</td>
							<td>用户密码</td>
						</tr>
						<tr>
							<td>new_user_pass</td>
							<td>是</td>
							<td>新密码</td>
						</tr>
						<tr>
							<td>new_user_eamil</td>
							<td>是</td>
							<td>新邮箱</td>
						</tr>
						<tr>
							<td>key</td>
							<td>根据系统配置</td>
							<td>操作密匙</td>
						</tr>
					</table><br>
					<label for="name">返回参数:</label></br>
					<table border="1" width="100%">
						<tr>
							<th bgcolor="#F5F5DC">名称</th>
							<th bgcolor="#F5F5DC">说明</th>
						</tr>
						<tr>
							<td>msg</td>
							<td><span style="color:red"><b>0</b></span>-登录成功<br>
								<span style="color:red"><b>1</b></span>-登录失败<br>
							</td>
						</tr>
						<tr>
							<td>info</td>
							<td>返回信息</td>
						</tr>
					</table><br>
					<label for="name">请求事例:</label></br>
					<textarea rows="10" class="form-control" name="content"  cols="30" readonly="readonly"  wrap="hard" >
t()
{
s a = "<?php echo dirname($url).'/api.php';?>"
s post = "act=modify&user_id=123456&user_pass=654321&new_user_pass=123456&new_user_email=3571717467@qq.com"
hs(a, post, "utf-8", b)
syso(b)
}
					</textarea>
<?php break;?>
<?php 
    case '找回密码':
    ?>
    					<h3 class="panel-title" align="center"><?php echo $_GET['act']?>调用文档</h3>
				</div>
				<div class="panel-body">
					<input type="submit" class="btn btn-primary btn-block"
						name="Submit" onclick="javascript:history.back(-1);" value="返回上一页"><br>
					<label for="name">提交地址:</label><br>
		<?php $url='http://'.$_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"]; echo dirname($url).'/api.php';?><br>
					<br> <label for="name">返回格式:</label><br> JSON<br>
					<br> <label for="name">提交方式:</label><br> POST<br>
					<br> <label for="name">请求参数:</label><br>

					<table border="1" width="100%">
						<tr>
							<th bgcolor="#F5F5DC">参数</th>
							<th bgcolor="#F5F5DC">必填</th>
							<th bgcolor="#F5F5DC">说明</th>
						</tr>
						<tr>
							<td>act</td>
							<td>是(pass)</td>
							<td>找回密码标识</td>
						</tr>
						<tr>
							<td>user_id</td>
							<td>是</td>
							<td>用户账号</td>
						</tr>
						<tr>
							<td>user_email</td>
							<td>是</td>
							<td>用户邮箱</td>
						</tr>
						<tr>
							<td>key</td>
							<td>根据系统配置</td>
							<td>操作密匙</td>
						</tr>
					</table><br>
					<label for="name">返回参数:</label></br>
					<table border="1" width="100%">
						<tr>
							<th bgcolor="#F5F5DC">名称</th>
							<th bgcolor="#F5F5DC">说明</th>
						</tr>
						<tr>
							<td>msg</td>
							<td><span style="color:red"><b>0</b></span>-找回成功<br>
								<span style="color:red"><b>1</b></span>-找回失败<br>
							</td>
						</tr>
						<tr>
							<td>info</td>
							<td>返回信息</td>
						</tr>
					</table><br>
					<label for="name">请求事例:</label></br>
					<textarea rows="10" class="form-control" name="content"  cols="30" readonly="readonly"  wrap="hard" >
t()
{
s a = "<?php echo dirname($url).'/api.php';?>"
s post = "act=pass&user_id=123456&user_email=3571717467@qq.com"
hs(a, post, "utf-8", b)
syso(b)
}
					</textarea>
<?php break;?>
<?php 
    case '用户签到':
    ?>
    					<h3 class="panel-title" align="center"><?php echo $_GET['act']?>调用文档</h3>
				</div>
				<div class="panel-body">
					<input type="submit" class="btn btn-primary btn-block"
						name="Submit" onclick="javascript:history.back(-1);" value="返回上一页"><br>
					<label for="name">提交地址:</label><br>
		<?php $url='http://'.$_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"]; echo dirname($url).'/api.php';?><br>
					<br> <label for="name">返回格式:</label><br> JSON<br>
					<br> <label for="name">提交方式:</label><br> POST<br>
					<br> <label for="name">请求参数:</label><br>

					<table border="1" width="100%">
						<tr>
							<th bgcolor="#F5F5DC">参数</th>
							<th bgcolor="#F5F5DC">必填</th>
							<th bgcolor="#F5F5DC">说明</th>
						</tr>
						<tr>
							<td>act</td>
							<td>是(signin)</td>
							<td>用户签到标识</td>
						</tr>
						<tr>
							<td>user_id</td>
							<td>是</td>
							<td>用户账号</td>
						</tr>
						<tr>
							<td>user_pass</td>
							<td>是</td>
							<td>用户密码</td>
						</tr>
						<tr>
							<td>key</td>
							<td>根据系统配置</td>
							<td>操作密匙</td>
						</tr>
					</table><br>
					<label for="name">返回参数:</label></br>
					<table border="1" width="100%">
						<tr>
							<th bgcolor="#F5F5DC">名称</th>
							<th bgcolor="#F5F5DC">说明</th>
						</tr>
						<tr>
							<td>msg</td>
							<td><span style="color:red"><b>0</b></span>-签到成功<br>
								<span style="color:red"><b>1</b></span>-签到失败<br>
							</td>
						</tr>
						<tr>
							<td>info</td>
							<td>返回信息</td>
						</tr>
					</table><br>
					<label for="name">请求事例:</label></br>
					<textarea rows="10" class="form-control" name="content"  cols="30" readonly="readonly"  wrap="hard" >
t()
{
s a = "<?php echo dirname($url).'/api.php';?>"
s post = "act=signin&user_id=123456&user_pass=654321"
hs(a, post, "utf-8", b)
syso(b)
}
					</textarea>
<?php break;?>
<?php 
    case '用户信息':
    ?>
    					<h3 class="panel-title" align="center"><?php echo $_GET['act']?>调用文档</h3>
				</div>
				<div class="panel-body">
					<input type="submit" class="btn btn-primary btn-block"
						name="Submit" onclick="javascript:history.back(-1);" value="返回上一页"><br>
					<label for="name">提交地址:</label><br>
		<?php $url='http://'.$_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"]; echo dirname($url).'/api.php';?><br>
					<br> <label for="name">返回格式:</label><br> JSON<br>
					<br> <label for="name">提交方式:</label><br> POST<br>
					<br> <label for="name">请求参数:</label><br>

					<table border="1" width="100%">
						<tr>
							<th bgcolor="#F5F5DC">参数</th>
							<th bgcolor="#F5F5DC">必填</th>
							<th bgcolor="#F5F5DC">说明</th>
						</tr>
						<tr>
							<td>act</td>
							<td>是(query)</td>
							<td>查询用户标识</td>
						</tr>
						<tr>
							<td>user_id</td>
							<td>是</td>
							<td>用户账号</td>
						</tr>
					</table><br>
					<label for="name">返回参数:</label></br>
					<table border="1" width="100%">
						<tr>
							<th bgcolor="#F5F5DC">名称</th>
							<th bgcolor="#F5F5DC">说明</th>
						</tr>
						<tr>
							<td>msg</td>
							<td><span style="color:red"><b>0</b></span>-查询成功<br>
								<span style="color:red"><b>1</b></span>-查询失败<br>
							</td>
						</tr>
						<tr>
							<td>info</td>
							<td>返回信息</td>
						</tr>
					</table><br>
					<label for="name">请求事例:</label></br>
					<textarea rows="10" class="form-control" name="content"  cols="30" readonly="readonly"  wrap="hard" >
t()
{
s a = "<?php echo dirname($url).'/api.php';?>"
s post = "act=query&user_id=123456"
hs(a, post, "utf-8", b)
syso(b)
}
					</textarea>
<?php break;?>
<?php 
    case '经验加减':
    ?>
    					<h3 class="panel-title" align="center"><?php echo $_GET['act']?>调用文档</h3>
				</div>
				<div class="panel-body">
					<input type="submit" class="btn btn-primary btn-block"
						name="Submit" onclick="javascript:history.back(-1);" value="返回上一页"><br>
					<label for="name">提交地址:</label><br>
		<?php $url='http://'.$_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"]; echo dirname($url).'/api.php';?><br>
					<br> <label for="name">返回格式:</label><br> JSON<br>
					<br> <label for="name">提交方式:</label><br> POST<br>
					<br> <label for="name">请求参数:</label><br>

					<table border="1" width="100%">
						<tr>
							<th bgcolor="#F5F5DC">参数</th>
							<th bgcolor="#F5F5DC">必填</th>
							<th bgcolor="#F5F5DC">说明</th>
						</tr>
						<tr>
							<td>act</td>
							<td>是(exp)</td>
							<td>经验加减标识</td>
						</tr>
						<tr>
						<tr>
							<td>op</td>
							<td>是(加-a减-r)</td>
							<td>加减标识</td>
						</tr>
						<tr>
							<td>user_id</td>
							<td>是</td>
							<td>用户账号</td>
						</tr>
						<tr>
							<td>user_pass</td>
							<td>是</td>
							<td>用户密码</td>
						</tr>
						<tr>
							<td>num</td>
							<td>是</td>
							<td>数量</td>
						</tr>
						<tr>
							<td>key</td>
							<td>根据系统配置(建议开启)</td>
							<td>操作密匙</td>
						</tr>
					</table><br>
					<label for="name">返回参数:</label></br>
					<table border="1" width="100%">
						<tr>
							<th bgcolor="#F5F5DC">名称</th>
							<th bgcolor="#F5F5DC">说明</th>
						</tr>
						<tr>
							<td>msg</td>
							<td><span style="color:red"><b>0</b></span>-操作成功<br>
								<span style="color:red"><b>1</b></span>-操作失败<br>
							</td>
						</tr>
						<tr>
							<td>info</td>
							<td>返回信息</td>
						</tr>
					</table><br>
					<label for="name">请求事例:</label></br>
					<textarea rows="10" class="form-control" name="content"  cols="30" readonly="readonly"  wrap="hard" >
t()
{
s a = "<?php echo dirname($url).'/api.php';?>"
s post = "act=exp&op=a&user_id=123456&user_pass=654321&num=10&key="
hs(a, post, "utf-8", b)
syso(b)
}
					</textarea>
<?php break;?>
<?php 
    case 'iB加减':
    ?>
    					<h3 class="panel-title" align="center"><?php echo $_GET['act']?>调用文档</h3>
				</div>
				<div class="panel-body">
					<input type="submit" class="btn btn-primary btn-block"
						name="Submit" onclick="javascript:history.back(-1);" value="返回上一页"><br>
					<label for="name">提交地址:</label><br>
		<?php $url='http://'.$_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"]; echo dirname($url).'/api.php';?><br>
					<br> <label for="name">返回格式:</label><br> JSON<br>
					<br> <label for="name">提交方式:</label><br> POST<br>
					<br> <label for="name">请求参数:</label><br>

					<table border="1" width="100%">
						<tr>
							<th bgcolor="#F5F5DC">参数</th>
							<th bgcolor="#F5F5DC">必填</th>
							<th bgcolor="#F5F5DC">说明</th>
						</tr>
						<tr>
							<td>act</td>
							<td>是(ib)</td>
							<td>iB加减标识</td>
						</tr>
						<tr>
						<tr>
							<td>op</td>
							<td>是(加-a减-r)</td>
							<td>加减标识</td>
						</tr>
						<tr>
							<td>user_id</td>
							<td>是</td>
							<td>用户账号</td>
						</tr>
						<tr>
							<td>user_pass</td>
							<td>是</td>
							<td>用户密码</td>
						</tr>
						<tr>
							<td>num</td>
							<td>是</td>
							<td>数量</td>
						</tr>
						<tr>
							<td>key</td>
							<td>根据系统配置(建议开启)</td>
							<td>操作密匙</td>
						</tr>
					</table><br>
					<label for="name">返回参数:</label></br>
					<table border="1" width="100%">
						<tr>
							<th bgcolor="#F5F5DC">名称</th>
							<th bgcolor="#F5F5DC">说明</th>
						</tr>
						<tr>
							<td>msg</td>
							<td><span style="color:red"><b>0</b></span>-操作成功<br>
								<span style="color:red"><b>1</b></span>-操作失败<br>
							</td>
						</tr>
						<tr>
							<td>info</td>
							<td>返回信息</td>
						</tr>
					</table><br>
					<label for="name">请求事例:</label></br>
					<textarea rows="10" class="form-control" name="content"  cols="30" readonly="readonly"  wrap="hard" >
t()
{
s a = "<?php echo dirname($url).'/api.php';?>"
s post = "act=ib&op=a&user_id=123456&user_pass=654321&num=10&key="
hs(a, post, "utf-8", b)
syso(b)
}
					</textarea>
<?php break;?>
<?php 
    case '风云榜':
    ?>
    					<h3 class="panel-title" align="center"><?php echo $_GET['act']?>调用文档</h3>
				</div>
				<div class="panel-body">
					<input type="submit" class="btn btn-primary btn-block"
						name="Submit" onclick="javascript:history.back(-1);" value="返回上一页"><br>
					<label for="name">提交地址:</label><br>
		<?php $url='http://'.$_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"]; echo dirname($url).'/api.php';?><br>
					<br> <label for="name">返回格式:</label><br> JSON<br>
					<br> <label for="name">提交方式:</label><br> POST<br>
					<br> <label for="name">请求参数:</label><br>

					<table border="1" width="100%">
						<tr>
							<th bgcolor="#F5F5DC">参数</th>
							<th bgcolor="#F5F5DC">必填</th>
							<th bgcolor="#F5F5DC">说明</th>
						</tr>
						<tr>
							<td>act</td>
							<td>是(rank)</td>
							<td>查询标识</td>
						</tr>
						<tr>
						<tr>
							<td>op</td>
							<td>是(经验-exp,iB-ib,签到-signin)</td>
							<td>查询排行标识</td>
						</tr>
					</table><br>
					<label for="name">返回参数:</label></br>
					<table border="1" width="100%">
						<tr>
							<th bgcolor="#F5F5DC">名称</th>
							<th bgcolor="#F5F5DC">说明</th>
						</tr>
						<tr>
							<td>msg</td>
							<td><span style="color:red"><b>0</b></span>-查询成功<br>
								<span style="color:red"><b>1</b></span>-查询失败<br>
							</td>
						</tr>
						<tr>
							<td>info</td>
							<td>返回信息</td>
						</tr>
					</table><br>
					<label for="name">请求事例:</label></br>
					<textarea rows="10" class="form-control" name="content"  cols="30" readonly="readonly"  wrap="hard" >
t()
{
s a = "<?php echo dirname($url).'/api.php';?>"
s post = "act=rank&op=exp"
hs(a, post, "utf-8", b)
syso(b)
}
					</textarea>
<?php break;?>
<?php 
    case '邀请查询':
    ?>
    					<h3 class="panel-title" align="center"><?php echo $_GET['act']?>调用文档</h3>
				</div>
				<div class="panel-body">
					<input type="submit" class="btn btn-primary btn-block"
						name="Submit" onclick="javascript:history.back(-1);" value="返回上一页"><br>
					<label for="name">提交地址:</label><br>
		<?php $url='http://'.$_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"]; echo dirname($url).'/api.php';?><br>
					<br> <label for="name">返回格式:</label><br> JSON<br>
					<br> <label for="name">提交方式:</label><br> POST<br>
					<br> <label for="name">请求参数:</label><br>

					<table border="1" width="100%">
						<tr>
							<th bgcolor="#F5F5DC">参数</th>
							<th bgcolor="#F5F5DC">必填</th>
							<th bgcolor="#F5F5DC">说明</th>
						</tr>
						<tr>
							<td>act</td>
							<td>是(cal)</td>
							<td>查询标识</td>
						</tr>
						<tr>
						<tr>
							<td>user_id</td>
							<td>是</td>
							<td>用户账号</td>
						</tr>
					</table><br>
					<label for="name">返回参数:</label></br>
					<table border="1" width="100%">
						<tr>
							<th bgcolor="#F5F5DC">名称</th>
							<th bgcolor="#F5F5DC">说明</th>
						</tr>
						<tr>
							<td>msg</td>
							<td><span style="color:red"><b>0</b></span>-查询成功<br>
								<span style="color:red"><b>1</b></span>-查询失败<br>
							</td>
						</tr>
						<tr>
							<td>info</td>
							<td>返回信息</td>
						</tr>
					</table><br>
					<label for="name">请求事例:</label></br>
					<textarea rows="10" class="form-control" name="content"  cols="30" readonly="readonly"  wrap="hard" >
t()
{
s a = "<?php echo dirname($url).'/api.php';?>"
s post = "act=cal&user_id=123456"
hs(a, post, "utf-8", b)
syso(b)
}
					</textarea>
<?php break;?>
<?php 
}
?>

				</div>
			</div>
		</div>
	</div>

</body>
</html>