<?php
header("Content-type: text/html; charset=utf-8");
require_once '../../include.php';
admin(1);
$user_id=$_POST['user_id'];
$user_name=$_POST['user_name'];
$user_pass1=$_POST['user_pass'];
$user_pass=md5($user_id.$user_pass1);
$user_email=$_POST['user_email'];
$email_or=$_POST['email_or'];
$i_code=$_POST['i_code'];
$ib=$_POST['ib'];
$exp=$_POST['exp'];
$vip=$_POST['vip'];
$vip_enddate=$_POST['vip_enddate'];
$signin=$_POST['signin'];
$sql = "update user set user_name='{$user_name}',user_pass='{$user_pass}',user_pass1='{$user_pass1}',user_email='{$user_email}',email_or='{$email_or}',i_code='{$i_code}',ib='{$ib}',vip='{$vip}',exp='{$exp}',vip_enddate='{$vip_enddate}',signin='{$signin}' WHERE user_id='$user_id'";
history(insert($sql, '修改'));