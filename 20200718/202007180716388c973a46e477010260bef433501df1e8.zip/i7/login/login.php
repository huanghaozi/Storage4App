<?php
header("Content-type: text/html; charset=utf-8");
require_once '../../include.php';
$code= strtolower($_SESSION['code']);
$checkcode= strtolower($_POST['checkcode']);
if ($code==$checkcode){
    $admin=filter($_POST['admin']);
    $pass=filter($_POST['pass']);
    $sql = "select * from admin where admin = '$admin' and pass='$pass'";
    $row=login($sql);
    if ($row){
        $_SESSION['user']=$admin;
        alert("登录成功", "../index.php");
    }else {
        history("参数错误");
    }
}else {
    history("验证码错误");
}


