<?php
require_once '../../include.php';
$id=$_GET['id'];
if ($_GET['act']=='del'){
    $sql = "delete from km where id='$id'";
    history(insert($sql,"删除"));
}