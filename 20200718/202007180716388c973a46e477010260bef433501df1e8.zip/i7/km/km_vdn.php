<?php
header('Content-Type:text/html; charset=utf-8');
require_once '../../include.php';
if ($_POST['km'] != null) {
    if (filter($_POST['km']) != $_POST['km']) {
        $arr = array(
            'msg' => 1,
            'info' => '非法操作'
        );
        echo json_encode($arr);
    } else {
        $km = $_POST['km'];
        $sql = "select * from km where km = '$km' and state='未使用'";
        $row = login($sql);
        if ($row) {
            $ros = one($sql);
            if ($ros['date_start'] == null) {
                $date_start = date("Y-m-d H:i:s");
                $a = '+' . $ros['num'] . ' ' . $ros['type'];
                $date_end = date("Y-m-d H:i:s", strtotime($a));
                if ($ros['type'] == 'y') {
                    $sql = "update km set date_start='{$date_start}',date_end='9999999999999999',state='已使用' WHERE km='$km'";
                    km($sql);
                    $arr = array(
                        'msg' => 0,
                        'info' => '卡密正确',
                        'end'=>'9999999999999999',
                    );
                    echo json_encode($arr);
                } else {
                    $sql = "update km set date_start='{$date_start}',date_end='$date_end',state='已使用' WHERE km='$km'";
                    km($sql);
                    $arr = array(
                        'msg' => 0,
                        'info' => '卡密正确',
                        'end'=>$date_end,
                    );
                    echo json_encode($arr);
                }
            } else {
                if (date("Y-m-d H:i:s")<$ros['date_end']){
                    $arr = array(
                        'msg' => 0,
                        'info' => '卡密正确',
                        'end'=>$ros['date_end'],
                    );
                    echo json_encode($arr);
                }
            }
        } else {
            $arr = array(
                'msg' => 1,
                'info' => '卡密错误或已使用'
            );
            echo json_encode($arr);
        }
    }
} else {
    $arr = array(
        'msg' => 1,
        'info' => '参数错误'
    );
    echo json_encode($arr);
}