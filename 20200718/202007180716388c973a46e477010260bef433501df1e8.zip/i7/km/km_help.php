<?php
require_once '../../include.php';
admin(1);
?>


<html lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport"
	content="initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0,user-scalable=no,minimal-ui">
<title>i7网络验证</title>
<link rel="stylesheet" type="text/css" href="../../css/boostrap.css" />
<style type="text/css">
.inputDiv {
	font-size: 0;
}
</style>
</head>
<body>
	<nav class="navbar navbar-fixed-top navbar-default">
		<div class="container">
			<div class="navbar-header">
				<span class="navbar-brand">i7网络验证</span>
			</div>
		</div>
	</nav>
	<div class="container" style="padding-top: 60px;">
		<div class="col-xs-12 col-sm-8 col-lg-6 center-block"
			style="float: none;">

			<div class="panel panel-primary">
				<div class="panel-heading">
        					<h3 class="panel-title" align="center">卡密调用文档</h3>
				</div>
				<div class="panel-body">
					<input type="submit" class="btn btn-primary btn-block"
						name="Submit" onclick="javascript:history.back(-1);" value="返回上一页"><br>
					<label for="name">提交地址:</label><br>
		<?php $url='http://'.$_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"]; echo dirname($url).'/km_vdn.php';?><br>
					<br> <label for="name">返回格式:</label><br> JSON<br>
					<br> <label for="name">提交方式:</label><br> POST<br>
					<br> <label for="name">请求参数:</label><br>

					<table border="1" width="100%">
						<tr>
							<th bgcolor="#F5F5DC">参数</th>
							<th bgcolor="#F5F5DC">必填</th>
							<th bgcolor="#F5F5DC">说明</th>
						</tr>
						<tr>
							<td>km</td>
							<td>是</td>
							<td>卡密</td>
						</tr>
					</table><br>
					<label for="name">返回参数:</label></br>
					<table border="1" width="100%">
						<tr>
							<th bgcolor="#F5F5DC">名称</th>
							<th bgcolor="#F5F5DC">说明</th>
						</tr>
						<tr>
							<td>msg</td>
							<td><span style="color:red"><b>0</b></span>-验证成功<br>
								<span style="color:red"><b>1</b></span>-验证失败<br>
							</td>
						</tr>
						<tr>
							<td>info</td>
							<td>返回信息</td>
						</tr>
					</table><br>
					<label for="name">请求事例:</label></br>
					<textarea rows="10" class="form-control" name="content"  cols="30" readonly="readonly"  wrap="hard" >
t()
{
s a = "<?php echo dirname($url).'/km_vdn.php';?>"
s post = "km=C9E265BEFF7F"
hs(a, post, "utf-8", b)
syso(b)
}
</textarea>


				</div>
			</div>
		</div>
	</div>

</body>
</html>