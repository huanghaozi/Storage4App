<?php
require_once '../../include.php';
admin(1);
?>



<html lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="viewport" content="initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0,user-scalable=no,minimal-ui">
<title>i7网络验证</title>
<link rel="stylesheet" type="text/css" href="../../css/boostrap.css"/>
<style type="text/css">
	.inputDiv {
  font-size: 0;
}
</style>
</head>
<body>
<nav class="navbar navbar-fixed-top navbar-default">
    <div class="container">
      <div class="navbar-header">
        <span class="navbar-brand">i7网络验证</span>
      </div>
    </div>
  </nav>
  <div class="container" style="padding-top:60px;">
    <div class="col-xs-12 col-sm-8 col-lg-6 center-block" style="float: none;">

<div class="panel panel-primary">
	<div class="panel-heading">
		<h3 class="panel-title" align="center">卡密系统</h3>
	</div>
	<div class="panel-body">
			
		<form action="km_add.php" class="form-sign" method="post">
		<label for="name">生成卡密数量:</label>
		<input type="text" class="form-control" name="kmnum" value="" placeholder="请输入数量(整数)" id="title">
		<label for="name">设置到期时间:</label></br>
		<table style="margin: 0px;padding: 0px;">
        <input type="text" class="controla" name="date" value="" placeholder="请输入到期时间(整数)" id="music" style="width: 70%;">
		<select name="type" class="controla" style="width: 30%;">
        <option value="hours">时卡</option>
        <option value="day">天卡</option>
        <option value="month">月卡</option>
        <option value="y">永久</option>
        </select>
		</table></br>
		<input type="submit" class="btn btn-primary btn-block" name="submit" value="一键生成">
		</form>
		<input type="submit" class="btn btn-primary btn-block" name="submit" value="查看卡密" onclick='location.href=("./km_list.php?act=i7")'>
		<input type="submit" class="btn btn-primary btn-block" name="submit" value="调用方法" onclick='location.href=("./km_help.php")'>
		<input type="submit" class="btn btn-primary btn-block" name="Submit" onclick="javascript:history.back(-1);" value="返回上一页"><br>
</div>
</div>
</div>
</div>

</body>
<script type="text/javascript">
	function aa(){
    document.getElementById('code').src="./code.php?"+Math.random();
}
</script>
</html>