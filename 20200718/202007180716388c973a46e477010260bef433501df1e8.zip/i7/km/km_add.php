<?php 
header('Content-Type:text/html; charset=utf-8');
require_once '../../include.php';
admin(1);
if ($_POST['kmnum']!=null  ||  $_POST['date']!=null){
    $num=$_POST['kmnum'];
    $date=$_POST['date'];
    $type=$_POST['type'];
    code($num, $date, $type);
}else {
    history("输入错误");
}









function code($num,$date,$type){
    set_time_limit(0);
    
    //处理缓冲区
    ob_end_clean();
    ob_implicit_flush(true);
    
    if(intval($num>0)) $num=intval($num); //数量
    for($i=1;$i<=$num;$i++)
    {
        $seek=mt_rand(0,9999).mt_rand(0,9999).mt_rand(0,9999); //12位
        $start=mt_rand(0,20);
        $str=strtoupper(substr(md5($seek),$start,12));
        $str=str_replace("O",chr(mt_rand(65,78)),$str);
        $str=str_replace("0",chr(mt_rand(65,78)),$str);
        $row=array('km'=>$str);
        $km=$row['km'];
        $sql="insert into km (km,type,num) values ('$km','$type','$date')";
        km($sql);
    }
    history("生成成功");
} //函数结束

?>