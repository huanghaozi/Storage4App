<?php

function connect(){
    $link=mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_DBNAME);
    mysqli_query($link, "set names utf8");
    return $link;
}

function login($sql){
    $link=connect();
    $result=mysqli_query($link,$sql);
    $row=mysqli_num_rows($result);
    return $row;
    mysqli_close($link);
}

function insert($sql,$text){
    $link=connect();
    if (mysqli_query($link,$sql)){
        return $text."成功";
    }else {
        return $text."失败";
    }
    mysqli_close($link);
}

function all($sql){
    $link=connect();
    $result=mysqli_query($link,$sql);
    if (mysqli_num_rows($result) > 0) {
            return $result;
    }else {
        return false;
    }
    mysqli_close($link);
}

function km($sql){
    $link=connect();
    mysqli_query($link,$sql);
    mysqli_close($link);
}

//一行
function one($sql){
    $link=connect();
    $result=mysqli_query($link,$sql);
    $row=mysqli_fetch_array($result);
    return $row;
    mysqli_close($link);
}
//num
function num($sql){
    $link=connect();
    $result=mysqli_query($link,$sql);
    $row=mysqli_num_rows($result);
    return $row;
    mysqli_close($link);
}

function red($sql){
    $link=connect();
    if (mysqli_query($link,$sql)){
        $arr = array(
            'msg' => 0,
            'info' => '注册成功'
        );
        $info= json_encode($arr,JSON_UNESCAPED_UNICODE);
        return $info;
    }else {
        $arr = array(
            'msg' => 5,
            'info' => '注册失败'
        );
        $info= json_encode($arr,JSON_UNESCAPED_UNICODE);
        return $info;
    }
    mysqli_close($link);
}

function user_exp($sql){
    $link=connect();
    if (mysqli_query($link,$sql)){
        $arr = array(
            'msg' => 0,
            'info' => '操作成功'
        );
        $info= json_encode($arr,JSON_UNESCAPED_UNICODE);
        return $info;
    }else {
        $arr = array(
            'msg' => 1,
            'info' => '操作失败'
        );
        $info= json_encode($arr,JSON_UNESCAPED_UNICODE);
        return $info;
    }
    mysqli_close($link);
}

function signin($sql){
    global $signin_exp,$signin_ib,$ib;
    $link=connect();
    if (mysqli_query($link,$sql)){
        $arr = array(
            'msg' => 0,
            'info' => '签到成功 '.$ib.'+'.$signin_ib.' 经验+'.$signin_exp
        );
        $info= json_encode($arr,JSON_UNESCAPED_UNICODE);
        return $info;
    }else {
        $arr = array(
            'msg' => 1,
            'info' => '签到失败'
        );
        $info= json_encode($arr,JSON_UNESCAPED_UNICODE);
        return $info;
    }
    mysqli_close($link);
}

/* 
function red_email($sql,$user_id,$user_email,$url){
    $link=connect();
    if (mysqli_query($link,$sql)){
        $arr = array(
            'msg' => 4,
            'info' => '注册成功,请邮箱激活'
        );
        $info= json_encode($arr,JSON_UNESCAPED_UNICODE);
        sendMail($user_email,'账号激活通知','尊敬的用户你好,你的激活链接为:'.dirname($url).'/api_email.php?user_id='.$user_id); 
        return $info;
    }else {
        $arr = array(
            'msg' => 6,
            'info' => '注册失败,系统错误'
        );
        $info= json_encode($arr,JSON_UNESCAPED_UNICODE);
        return $info;
    }
    mysqli_close($link);
}
 */


