<?php
/**
 * 跳转信息及跳转地址
 * @param unknown $info
 * @param unknown $url
 */
function alert($info,$url){
    echo "<script>alert('{$info}');</script>";
    echo "<script>window.location='{$url}';</script>";
}

/**
 * 返回上一页并刷新
 * @param unknown $info
 */
function history($info){
    echo "<script>alert('{$info}');location.href='".$_SERVER["HTTP_REFERER"]."';</script>"; 
}

function dialog($info){
    echo "<script>alert('{$info}');</script>";
}